let policial;
let ladrao;
let jogoAcabou = false;

// Classe para representar o Policial ou o Ladrão
class Personagem {
  constructor(x, y, cor, velocidade) {
    this.x = x;
    this.y = y;
    this.raio = 20;
    this.cor = cor;
    this.velocidade = velocidade;
  }

  // Desenha o personagem na tela
  display() {
    fill(this.cor);
    noStroke();
    ellipse(this.x, this.y, this.raio * 2);
  }

  // Atualiza a posição do ladrão com base nas teclas pressionadas
  moverLadrao() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.velocidade;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.velocidade;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= this.velocidade;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y += this.velocidade;
    }

    // Limita o ladrão dentro da tela
    this.x = constrain(this.x, this.raio, width - this.raio);
    this.y = constrain(this.y, this.raio, height - this.raio);
  }

  // Atualiza a posição do policial para seguir o ladrão
  moverPolicial(ladraoX, ladraoY) {
    let direcaoX = ladraoX - this.x;
    let direcaoY = ladraoY - this.y;
    let distancia = dist(this.x, this.y, ladraoX, ladraoY);

    if (distancia > 1) { // Evita divisão por zero e pequenos movimentos quando muito perto
      this.x += (direcaoX / distancia) * this.velocidade;
      this.y += (direcaoY / distancia) * this.velocidade;
    }
  }

  // Verifica se houve colisão entre dois personagens
  checarColisao(outroPersonagem) {
    let distancia = dist(this.x, this.y, outroPersonagem.x, outroPersonagem.y);
    return distancia < (this.raio + outroPersonagem.raio);
  }
}

function setup() {
  createCanvas(600, 400);
  // Inicializa o policial (azul) e o ladrão (vermelho)
  policial = new Personagem(width / 4, height / 2, color(0, 0, 255), 3); // Policial um pouco mais lento
  ladrao = new Personagem(width * 3 / 4, height / 2, color(255, 0, 0), 4); // Ladrão um pouco mais rápido
}

function draw() {
  background(220); // Fundo cinza claro

  if (!jogoAcabou) {
    // Atualiza e desenha o ladrão
    ladrao.moverLadrao();
    ladrao.display();

    // Atualiza e desenha o policial
    policial.moverPolicial(ladrao.x, ladrao.y);
    policial.display();

    // Verifica a colisão
    if (policial.checarColisao(ladrao)) {
      jogoAcabou = true;
    }
  } else {
    // Tela de "Game Over"
    fill(0);
    textAlign(CENTER, CENTER);
    textSize(32);
    text("Ladrão Capturado!", width / 2, height / 2);
    textSize(16);
    text("Pressione 'R' para Reiniciar", width / 2, height / 2 + 40);
  }
}

function keyPressed() {
  // Reinicia o jogo se a tecla 'R' for pressionada após o fim do jogo
  if (jogoAcabou && key === 'r' || key === 'R') {
    jogoAcabou = false;
    policial = new Personagem(width / 4, height / 2, color(0, 0, 255), 3);
    ladrao = new Personagem(width * 3 / 4, height / 2, color(255, 0, 0), 4);
  }
}